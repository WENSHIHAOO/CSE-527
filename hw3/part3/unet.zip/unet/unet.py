import torch.nn as nn
import torch
import torchvision.models


class SumUNet(nn.Module):
    def __init__(self, n_class, load_pretrained_encoder_layers=False):
        super().__init__()

        pass

    def forward(self, input):
        pass


class UNet(nn.Module):
    def __init__(self, n_class, load_pretrained_encoder_layers=False):
        super().__init__()

        pass

    def forward(self, input):
        pass
